/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.api;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

/**
 *
 * @author NAD
 */
public class DBApi {

    //define kat atas jdi x perlu define byk kali
    static Connection con;
    static ResultSet rs;

    //return json object
    public static JSONObject registerNewCall(String name, String phone) {
        JSONObject jo = new JSONObject();
        int ada = 0; //currently no data in the database
        try {
            con = ConMan.getConnection();
            String sql = "select * from register where name = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, name);
            rs = ps.executeQuery();
            while (rs.next()) {
                ada = 1;
            }
            if (ada == 1) {
                jo.put("status", 1); //user exist,return value jsaon status dgn nilai 1
            } else { //user not yet exist, add user into table
                sql = "insert into register(name, phone) value (?,?)";
                PreparedStatement ps2 = con.prepareStatement(sql);
                ps2.setString(1, name);
                ps2.setString(2, phone);
                ps2.executeUpdate();
                jo.put("status", 0);

            }
        } catch (SQLException e) {
            e.printStackTrace();

        }
        return jo; //result from DBApi go to servlet register
    }

    public static JSONObject getCallDataById(String id) {
        JSONObject jo = new JSONObject();
        int index = 0;
        int ada = 0;
        try {
            con = ConMan.getConnection();
            String sql = "select * from register where id = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                ada = 1;

                jo.put("id", rs.getString("id"));
                jo.put("name", rs.getString("name"));
                jo.put("phone", rs.getString("phone"));
               

            }
            if (ada == 1) {//ada data account

                jo.put("status", 1);

            } else {//tdk data

                jo.put("status", 0);

            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return jo;
    }
}
