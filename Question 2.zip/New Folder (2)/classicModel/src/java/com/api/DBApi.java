/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.api;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

/**
 *
 * @author NAD
 */
public class DBApi {

    //define kat atas jdi x perlu define byk kali
    static Connection con;
    static ResultSet rs;

    //return json object
    public static JSONObject registerNewUser(String email, String password, String id) {
        JSONObject jo = new JSONObject();
        int ada = 0; //currently no data in the database
        try {
            con = ConMan.getConnection();
            String sql = "select * from register where email = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, email);
            rs = ps.executeQuery();
            while (rs.next()) {
                ada = 1;
            }
            if (ada == 1) {
                jo.put("status", 1); //user exist,return value jsaon status dgn nilai 1
            } else { //user not yet exist, add user into table
                sql = "insert into register (email, password, id) value (?,?,?)";
                PreparedStatement ps2 = con.prepareStatement(sql);
                ps2.setString(1, email);
                ps2.setString(2, password);
                ps2.setString(3, id);
                ps2.executeUpdate();
                jo.put("status", 0);

            }
        } catch (SQLException e) {
            e.printStackTrace();

        }
        return jo; //result from DBApi go to servlet register
    }

    public static JSONObject userAuthentication(String email, String pass, String id) {
        JSONObject jo = new JSONObject();
        int ada = 0; //currently no data in the database
        try {
            con = ConMan.getConnection();
            String sql = "select * from register where email = ? ,password = ? and id = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, email);
            ps.setString(2, pass);
            ps.setString(3, id);

            rs = ps.executeQuery();
            while (rs.next()) {
                ada = 1;
            }
            if (ada == 1) {
                jo.put("status", 1); //user exist hntr status
            } else {
                jo.put("status", 0); //kalu xdok user(db) status 0 

            }
        } catch (SQLException e) {
            e.printStackTrace();

        }
        return jo;
    }

    public static JSONArray getStaffData(String email) {
        JSONArray ja = new JSONArray();
        int index = 0;
        int ada = 0;
        try {
            con = ConMan.getConnection();
            String sql = "select * from account where ownerEmail = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, email);
            rs = ps.executeQuery();
            while (rs.next()) {
                ada = 1;
                JSONObject jo = new JSONObject();
                jo.put("id", rs.getString("id"));
                jo.put("firstname", rs.getString("firstname"));
                jo.put("extension", rs.getString("extension"));
                jo.put("jobtitle", rs.getString("jobtitle"));
                jo.put("lastname", rs.getString("lastname"));
                jo.put("email", rs.getString("email"));
                
                ja.add(index++, jo);

            }
            if (ada == 1) {//ada data account
                JSONObject jo = new JSONObject();
                jo.put("status", 1);
                ja.add(index++, jo);

            } else {//tdk data
                JSONObject jo = new JSONObject();
                jo.put("status", 0);
                ja.add(index++, jo);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ja;
    }

    public static JSONObject addStaffData(String id, String firstname, String extension, String jobtitle , String lastname, String email, String ownerEmail) {
        JSONObject jo = new JSONObject();
        int ada = 0;
        try {
            con = ConMan.getConnection();
            
            String sql = "insert into staff (id,firstname,extension,jobtitle,lastname,email,ownerEmail) values(?,?,?,?,?,?,?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, id);
            ps.setString(2, firstname);
            ps.setString(3, extension);
            ps.setString(4, jobtitle);
            ps.setString(5, lastname);
            ps.setString(6, email);
            ps.setString(7, ownerEmail);
            ps.executeUpdate();
            jo.put("status", 1);

        } catch (SQLException e) {
            e.printStackTrace();

        }
        return jo;
    }

    public static JSONObject getStaffDataById(String id) {
        JSONObject jo = new JSONObject();
        int index = 0;
        int ada = 0;
        try {
            con = ConMan.getConnection();
            String sql = "select * from staff where id = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                ada = 1;

                jo.put("id", rs.getString("id"));
                jo.put("firstname", rs.getString("firstname"));
                jo.put("extension", rs.getString("extension"));
                jo.put("jobtitle", rs.getString("jobtitle"));
                jo.put("lastname", rs.getString("lastname"));
                jo.put("email", rs.getString("email"));
               

            }
            if (ada == 1) {//ada data account

                jo.put("status", 1);

            } else {//tdk data

                jo.put("status", 0);

            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return jo;
    }

    public static JSONObject updateStaffById(String firstname, String extension, String jobtitle , String lastname, String email, String staffid) {
        JSONObject jo = new JSONObject();
        int ada = 0;
        try {
            con = ConMan.getConnection();
            String sql = "update staff set firstname = ?, extension = ?, jobtitle = ? , lastname = ? , email=? where id=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, firstname);
            ps.setString(2, extension);
            ps.setString(3, jobtitle);
            ps.setString(4, lastname);
            ps.setString(5, email);
            ps.setString(6, staffid);
            ps.executeUpdate();
            jo.put("status", 1);

        } catch (SQLException e) {
            e.printStackTrace();

        }
        return jo;
    }

    public static JSONObject delStaffById(String staffid) {
        JSONObject jo = new JSONObject();

        try {
            con = ConMan.getConnection();
            String sql = "delete from staff where id=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, staffid);
            ps.executeUpdate();
            jo.put("status", 1);

        } catch (SQLException e) {
            e.printStackTrace();

        }
        return jo;
    }
}
